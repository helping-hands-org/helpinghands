
# Freelancer Website

## Run Frontend
Open frontend/index.html in browser

## Run Backend
npm install express cors
node server.js
